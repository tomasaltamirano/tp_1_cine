-- ============================================================================
-- CineApp · Migración 04: alta de funciones por el admin, con asignación
-- automática de sala y sin solapamientos (30 minutos de por medio).
--
-- Reemplaza el uso de 03_datos_demo_funciones.sql. Requiere 01 y 02. Re-ejecutable.
-- ============================================================================

-- ---------- 1. Política de escritura de funciones: solo admin ----------------
-- (la lectura pública ya la da la política "Lectura pública" del schema)
drop policy if exists "funciones_admin_escribe" on public.funciones;
create policy "funciones_admin_escribe" on public.funciones
  for all using (public.es_admin()) with check (public.es_admin());

-- ---------- 2. Alta de función con sala automática ---------------------------
-- fecha_hora_fin = inicio + duración de la película + 30 min de limpieza.
-- Esos mismos 30 min funcionan como el margen obligatorio entre funciones:
-- alcanza con que dos funciones de una sala no se superpongan en ese rango.
--
-- La asignación de sala es automática: recorre las salas (por nombre) y
-- devuelve la primera sin superposición. Si ninguna sala está libre a ese
-- horario, informa el error para que se pruebe otro horario.
create or replace function public.crear_funcion(
  p_pelicula_id uuid,
  p_fecha_hora_inicio timestamptz,
  p_formato text,
  p_idioma text,
  p_precio_base numeric,
  p_precio_vip numeric default null,
  p_es_preventa boolean default false,
  p_precio_preventa numeric default null,
  p_fecha_fin_preventa timestamptz default null
)
returns public.funciones
language plpgsql
security definer
set search_path = public
as $$
declare
  v_duracion integer;
  v_fin timestamptz;
  v_sala_id uuid;
  v_funcion public.funciones;
begin
  if not public.es_admin() then
    raise exception 'No autorizado' using errcode = '42501';
  end if;
  if p_fecha_hora_inicio <= now() then
    raise exception 'La función tiene que empezar en el futuro';
  end if;

  select duracion_minutos into v_duracion from public.peliculas where id = p_pelicula_id;
  if v_duracion is null then
    raise exception 'La película no existe';
  end if;
  v_fin := p_fecha_hora_inicio + make_interval(mins => v_duracion + 30);

  select s.id into v_sala_id
  from public.salas s
  where not exists (
    select 1 from public.funciones f
    where f.sala_id = s.id
      and f.fecha_hora_inicio < v_fin
      and f.fecha_hora_fin > p_fecha_hora_inicio
  )
  order by s.nombre
  limit 1;

  if v_sala_id is null then
    raise exception 'No hay salas libres en ese horario (recordá el margen de 30 minutos entre funciones). Probá otro horario.'
      using errcode = 'P0001';
  end if;

  insert into public.funciones (
    pelicula_id, sala_id, fecha_hora_inicio, fecha_hora_fin, formato, idioma,
    precio_base, precio_vip, es_preventa, precio_preventa, fecha_fin_preventa
  ) values (
    p_pelicula_id, v_sala_id, p_fecha_hora_inicio, v_fin, p_formato, p_idioma,
    p_precio_base, p_precio_vip, p_es_preventa, p_precio_preventa, p_fecha_fin_preventa
  )
  returning * into v_funcion;

  return v_funcion;
end;
$$;

revoke all on function public.crear_funcion(uuid, timestamptz, text, text, numeric, numeric, boolean, numeric, timestamptz) from public, anon;
grant execute on function public.crear_funcion(uuid, timestamptz, text, text, numeric, numeric, boolean, numeric, timestamptz) to authenticated;

-- ---------- 3. Cancelar una función (por si se cargó mal) --------------------
-- Solo si todavía no tiene compras. Si ya vendió entradas, hay que manejarlo
-- a mano (cancelar esas compras primero) para no perder el historial.
create or replace function public.eliminar_funcion(p_funcion_id uuid)
returns void
language plpgsql
security definer
set search_path = public
as $$
begin
  if not public.es_admin() then
    raise exception 'No autorizado' using errcode = '42501';
  end if;
  if exists (select 1 from public.compras where funcion_id = p_funcion_id) then
    raise exception 'Esta función ya tiene compras asociadas: no se puede eliminar.';
  end if;
  delete from public.funciones where id = p_funcion_id;
end;
$$;

revoke all on function public.eliminar_funcion(uuid) from public, anon;
grant execute on function public.eliminar_funcion(uuid) to authenticated;
